import { v4 as uuidv4 } from 'uuid';
const databaseManager = require('./databaseManager');

exports.handler = async (event) => {

	console.log(`EVENT => ${JSON.stringify(event)}`);

    let stage = event.requestContext.stage;
    console.log(`stage => ${stage}`);
    
	return saveItem(stage, event);
};


function saveItem(stage, event) {
	const item = JSON.parse(event.body);
	item.itemId = uuidv4();

	return databaseManager.saveItem(stage, item).then(response => {
		console.log('response => ', response);
		return sendResponse(200, item.itemId);
	});
}

function sendResponse(statusCode, message) {
	const response = {
		statusCode: statusCode,
		 headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*' // replace with hostname of frontend (CloudFront)
        },
		body: JSON.stringify(message)
	};
	return response
}